<?php 

	$mysqli = new mysqli("localhost","root", "","pewebdb");
	if ($mysqli->connect_errno) 
	{
		echo "Failed to connect to MySQL: " . $mysqli->connect_error;
	}

	$chk = $_POST['check'];

		unlink('img/'.$chk.'.jpg');

	$mysqli->query("DELETE FROM mobil where idmobil = $chk");
	$res = $mysqli->query("SELECT mo.*,me.nama FROM mobil mo left join merek me on mo.idmerk=me.idmerk");

	echo "<table border = '1'>
		<tr>
			<th>Gambar</th>
			<th>Merek</th>
			<th>Tipe</th>
			<th>Action</th>
		</tr>";
		while($row = $res->fetch_assoc()) {
			echo "<tr>
				<td><img src='img/".$row['idmobil'].".jpg' width = 100px></td>  
			 	<td>". $row['nama']."</td> 
			 	<td id='a'>".$row['tipe']."</td>
			 	<td><button class='update' value='".$row['idmobil']."'>Update</button><br><button class='delete' value='".$row['idmobil']."'>Delete</button></td>
			 	</tr>";
			 }

			echo "</table>" ;
			$mysqli->close();
 ?>