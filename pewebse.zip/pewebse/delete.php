<?php 

	$mysqli = new mysqli("localhost","root", "","pewebdb");
	if ($mysqli->connect_errno) 
	{
		echo "Failed to connect to MySQL: " . $mysqli->connect_error;
	}

	$chk = $_POST['check'];

	
	$id = '('.$chk[0];
	for ($i=1; $i<count($chk); $i++) { 
		$id .= ",".$chk[$i];
	}
	$id.=")";
	//echo $id;
		echo $chk[0];
	
		$gbr = $chk[0];
		for ($i=1; $i<count($chk); $i++) { 
		$gbr .= ",".$chk[$i];
		}
		unlink('img/'.$gbr.'.jpg');

	$mysqli->query("DELETE FROM mobil where idmobil in $id");
	$res = $mysqli->query("SELECT mo.*,me.nama FROM mobil mo left join merek me on mo.idmerk=me.idmerk");

	echo "<table border = '1'>
		<tr>
			<th>Bandingkan</th>
			<th>Gambar</th>
			<th>Merek</th>
			<th>Tipe</th>
		
		</tr>";
		$jumlah=0;
		while($row = $res->fetch_assoc()) {
			echo "<tr>
				<td><input type='checkbox' name='chek' id='chk' value='".$row['idmobil']."'></td> 
				<td><img src='img/".$row['idmobil'].".jpg' width = 100px></td>  
			 	<td>". $row['nama']."</td> 
			 	<td id='a'>".$row['tipe']."</td>
			 	</tr>";
			 	$jumlah++;
			 }

			echo "</table>" ;
			echo "<input type='text' id='jumlah' value='$jumlah' hidden>";
			$mysqli->close();
 ?>