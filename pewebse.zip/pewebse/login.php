
<form method="post" action="validasiLogin.php">
	Username : <input type="text" name="name"> 
	<br>
	Password : <input type="Password" name="pass">
	<br>
	<input type="submit" name="submit" value="Login">
</form>

